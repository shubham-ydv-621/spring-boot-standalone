package com.example.FoodManagementSystem.model;

import java.util.Date;

public class OrdersClass {
	
	private int orderId;
	private int userId;
	public OrdersClass(int orderId, int userId, Date orderDate, int price) {
		super();
		this.orderId = orderId;
		this.userId = userId;
		OrderDate = orderDate;
		Price = price;
	}
	
	public OrdersClass() {
		
	}
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public Date getOrderDate() {
		return OrderDate;
	}
	public void setOrderDate(Date orderDate) {
		OrderDate = orderDate;
	}
	private Date OrderDate;
	private int Price;
	public int getPrice() {
		return Price;
	}

	public void setPrice(int price) {
		this.Price = price;
	}
	 

}
