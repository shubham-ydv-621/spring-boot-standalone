package com.example.FoodManagementSystem.model;

public class OrderDetailsClass {

}
