package com.example.FoodManagementSystem.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.FoodManagementSystem.dao.orders.*;
import com.example.FoodManagementSystem.model.OrdersClass;
import com.example.FoodManagementSystem.model.UserClass;


@RestController
public class OrderController {
	@Autowired
	public Orders order;
	
	@GetMapping("/orders/{userId}")
	public List<OrdersClass> getAllOrders(@PathVariable("userId") int userId){
		return order.getAllOrders(userId);
	}
	
	@GetMapping("/orders/{userId}/{orderId}")
	public OrdersClass getOrderById(@PathVariable("userId") int userId , @PathVariable("orderId") int orderId) {
		return order.getOrderById(orderId, userId);
	}
	
	@PostMapping("/orders/create")
	public String saveOrder(@RequestBody OrdersClass saveOrder) {
		int result = order.saveOrder(saveOrder);
		if (result == 1) {
            return "Order saved successfully";
        } else {
            return "Failed to save Order";
        }
	}
	
	@GetMapping("/orders/delete/{userId}/{orderId}")
	public int deleteOrderById(@PathVariable("userId") int userId , @PathVariable("orderId") int orderId) {
		return order.deleteOrder(orderId, userId);
	}
}
