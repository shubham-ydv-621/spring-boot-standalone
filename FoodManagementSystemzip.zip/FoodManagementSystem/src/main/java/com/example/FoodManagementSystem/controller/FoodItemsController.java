package com.example.FoodManagementSystem.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.FoodManagementSystem.dao.FoodItems.FoodItems;
import com.example.FoodManagementSystem.model.FoodItemsClass;


@RestController
public class FoodItemsController {
	@Autowired
	public FoodItems foodItem;
	
	@GetMapping("/fooditems/{FoodId}")
	public FoodItemsClass getAllFoodByFoodId(@PathVariable("FoodId") int FoodId){
		return foodItem.getAllFoodItemsByFoodId(FoodId);
	}
	
	@GetMapping("/allfooditems")
	public List<FoodItemsClass> getAllFood(){
		return foodItem.getAllFoodItems();
	}
	
//	***************************************************
//	***************************************************
	
	@PostMapping("/fooditem/update/{FoodId}")
	public int updateFood(@PathVariable("FoodId") int FoodId) {
		return foodItem.UpdateFood(FoodId);
	}
	
	@GetMapping("/fooditems/delete/{FoodId}")
	public int deleteFoodId(@PathVariable("FoodId") int FoodId){
		return foodItem.delete(FoodId);
	}
	
	
	@PostMapping("/fooditem/create")
	public String SaveFoodItem(@RequestBody FoodItemsClass FoodItems) {
		int result = foodItem.saveFood(FoodItems);
		if (result == 1) {
            return "FoodItem saved successfully";
        } else {
            return "Failed to save FoodItems";
        }
	}
	
	
	
	

}
