package com.example.FoodManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodManagementSystemApplication.class, args);
	}

}
