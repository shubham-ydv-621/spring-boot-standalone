package com.example.FoodManagementSystem.dao.FoodItems;

import java.util.*;
import com.example.FoodManagementSystem.model.FoodItemsClass;

public interface FoodItems {
	int saveFood(FoodItemsClass FoodItem);
	int UpdateFood(int FoodId);
	int delete(int id);
	List<FoodItemsClass> getAllFoodItems();
	FoodItemsClass getAllFoodItemsByFoodId(int FoodId);
}
