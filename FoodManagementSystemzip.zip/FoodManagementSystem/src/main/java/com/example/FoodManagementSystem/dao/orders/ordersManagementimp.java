package com.example.FoodManagementSystem.dao.orders;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.FoodManagementSystem.model.OrdersClass;

@Repository
public class ordersManagementimp implements Orders {
	@Autowired
	JdbcTemplate JdbcTemplate;

	@Override
	public int saveOrder(OrdersClass order) {
		System.out.println(order.getPrice());
		return JdbcTemplate.update("INSERT INTO orders (userId , Price ) VALUES (?, ?)" ,order.getUserId(), order.getPrice());
	}

	@Override
	public int deleteOrder(int orderId, int userId) {
	    return JdbcTemplate.update("DELETE FROM orders WHERE orderId = ? AND userId = ?", orderId, userId);
	}

	@Override
	public List<OrdersClass> getAllOrders(int userId) {
		return JdbcTemplate.query("SELECT * FROM foodmanagementsystem.orders where userid = ? ", new BeanPropertyRowMapper<OrdersClass>(OrdersClass.class) , userId);
	}

	@Override
	public OrdersClass getOrderById(int id, int userId) {
		return JdbcTemplate.queryForObject("SELECT * FROM foodmanagementsystem.orders where userId = ? AND orderId=? ", new BeanPropertyRowMapper<OrdersClass>(OrdersClass.class),  userId , id);
	}
}
