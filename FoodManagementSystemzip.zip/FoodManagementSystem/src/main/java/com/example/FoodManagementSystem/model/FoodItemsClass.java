package com.example.FoodManagementSystem.model;
import java.util.*;

public class FoodItemsClass {
	
	private int FoodId;
	private int Quantity;
	private String Name;
	private Date  ManufacturingDate;
	private Date  ExpirationDate;
	private String Category;
	public int getFoodId() {
		return FoodId;
	}
	public void setFoodId(int foodId) {
		FoodId = foodId;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Date getManufacturingDate() {
		return ManufacturingDate;
	}
	public void setManufacturingDate(Date manufacturingDate) {
		ManufacturingDate = manufacturingDate;
	}
	public Date getExpirationDate() {
		return ExpirationDate;
	}
	public void setExpirationDate(Date expirationDate) {
		ExpirationDate = expirationDate;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}

}
