package com.example.FoodManagementSystem.dao.orders;

import java.util.*;

import com.example.FoodManagementSystem.model.OrdersClass;

public interface Orders {
	int saveOrder(OrdersClass order );
	int deleteOrder(int id , int userId);
	List<OrdersClass> getAllOrders(int userId);
	OrdersClass getOrderById(int id , int userId);
}
