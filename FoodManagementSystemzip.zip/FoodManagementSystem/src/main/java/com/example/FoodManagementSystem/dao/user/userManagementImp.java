package com.example.FoodManagementSystem.dao.user;


import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.FoodManagementSystem.model.UserClass;

@Repository
public class userManagementImp implements User {
	
	@Autowired
	JdbcTemplate JdbcTemplate;

	@Override
	public int saveUser(UserClass user) {
		return JdbcTemplate.update("INSERT INTO user (username, email) VALUES (?, ?)" , user.getUsername() , user.getEmail());
	}

	@Override
	public int updateUser(UserClass user, int id) {
		return JdbcTemplate.update("UPDATE user SET username = ?, email = ?, isAdmin = ? WHERE userId = ?" , user.getUsername() , user.getEmail(), id);
	}

	@Override
	public int delete(int id) {
        return JdbcTemplate.update("DELETE FROM user WHERE userId = ?", id);
	}

	@Override
	public List<UserClass> getAllUser() {
		// TODO Auto-generated method stub
		return JdbcTemplate.query("SELECT * FROM foodmanagementsystem.user", new BeanPropertyRowMapper<UserClass>(UserClass.class));
	}

	@Override
	public UserClass getAllUserById(int userId) {
		// TODO Auto-generated method stub
		return JdbcTemplate.queryForObject("SELECT * FROM foodmanagementsystem.user where userId = ? ", new BeanPropertyRowMapper<UserClass>(UserClass.class),  userId);
	}

}
