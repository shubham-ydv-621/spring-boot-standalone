package com.example.FoodManagementSystem.controller;


import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.FoodManagementSystem.dao.user.*;
import com.example.FoodManagementSystem.model.UserClass;

@RestController
public class UserController {
	@Autowired
	public User user;

	@GetMapping("/users")
	public List<UserClass> getAllUser(){
		return user.getAllUser();
	}
	
	@GetMapping("/user/{userId}")
	public UserClass getEmployeeById(@PathVariable("userId") int userId) {
		return user.getAllUserById(userId);

	}
	
	@GetMapping("/user/delete/{userId}")
	public int deleteUser(@PathVariable("userId") int userId) {
		return user.delete(userId);
	}
	
	 @PostMapping("/user/save")
	 public String saveUser(@RequestBody UserClass saveUser) {
		 int result =user.saveUser(saveUser);
		 if (result == 1) {
	            return "User saved successfully";
	        } else {
	            return "Failed to save user";
	        }
	 }
	
	
}
