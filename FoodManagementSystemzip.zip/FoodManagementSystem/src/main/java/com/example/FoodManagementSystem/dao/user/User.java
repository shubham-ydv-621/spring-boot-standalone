package com.example.FoodManagementSystem.dao.user;

import java.util.List;

import com.example.FoodManagementSystem.model.UserClass;

public interface User {
	int saveUser(UserClass user);
	int updateUser(UserClass user , int id);
	int delete(int id);
	List<UserClass> getAllUser();
	UserClass getAllUserById(int id);
}
