package com.example.FoodManagementSystem.dao.FoodItems;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


import com.example.FoodManagementSystem.model.FoodItemsClass;


@Repository
public class FoodItemsImp implements FoodItems{
	
	@Autowired
	JdbcTemplate JdbcTemplate;

	@Override
	public int saveFood(FoodItemsClass FoodItem) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int UpdateFood(int FoodId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(int foodId) {
	    String sql = "DELETE FROM fooditems WHERE FoodID = ?";
	    return JdbcTemplate.update(sql, foodId);
	}

	@Override
	public List<FoodItemsClass> getAllFoodItems() {
	    String sql = "SELECT * FROM fooditems";
	    return JdbcTemplate.query(sql, new BeanPropertyRowMapper<>(FoodItemsClass.class));
	}

	@Override
	public FoodItemsClass getAllFoodItemsByFoodId(int FoodId) {
		String sql = "SELECT * FROM fooditems WHERE FoodID = ?";
	    return JdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<>(FoodItemsClass.class), FoodId);
	}
}
